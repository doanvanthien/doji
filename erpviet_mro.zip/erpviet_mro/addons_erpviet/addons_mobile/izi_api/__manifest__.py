# -*- coding: utf-8 -*-
{
    "name": "API Repository Mobile ERPViet",
    "category": "Hidden",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    'author': "ERPViet",
    'version': '0.1',
    'depends': ['izi_api_repository']
}
