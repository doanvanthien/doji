# -*- coding: utf-8 -*-
{
    'name': 'ERPVIET - Ghi tăng tài sản khi import đầu kỳ',
    'description': """
        Tự động tạo phiếu ghi tăng kế toán khi xác nhận import tài sản đầu kỳ.
        Module mở rộng, cài thêm khi hệ thống cần tích hợp ghi tăng sau import.
    """,
    'sequence': 33,
    'author': 'IZISolution',
    'license': 'LGPL-3',
    'website': 'https://izisolution.vn',
    'category': 'Asset',
    'version': '0.1',
    'depends': ['ev_account_asset_import_tsdk', 'ev_account_asset_revaluation'],
    'data': [
        'views/cap_nhat_tsdk_views.xml',
        'wizard/cap_nhat_tsdk_tmp_views.xml',
    ],
    'demo': [],
}
