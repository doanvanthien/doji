# -*- coding: utf-8 -*-
{
    'name': 'Asset Depreciation Post',
    'category': 'Hidden',
    'version': '16.0.1.1.0',
    'author': 'ERPViet',
    'website': 'https://erpviet.vn',
    'license': 'LGPL-3',
    'depends': [
        'ev_account_asset_base',
        'ev_account_asset_accounting',
        'ev_account_asset_asset',
        'ev_account_asset_revaluation', #depend để lấy statbutton để xpath.
        'queue_job',
    ],
    'data': [
        'security/ir.model.access.csv',
        'security/record_rules.xml',
        'views/depreciation_post_views.xml',
    ],
}
