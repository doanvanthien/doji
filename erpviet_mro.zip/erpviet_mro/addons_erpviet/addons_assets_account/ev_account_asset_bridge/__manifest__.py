# -*- coding: utf-8 -*-
{
    'name': 'Asset Bridge: Quản trị → Kế toán',
    'summary': 'Kết nối thanh lý, báo mất, tiêu hủy với phiếu ghi giảm kế toán',
    'category': 'Assets',
    'version': '16.0.1.0.0',
    'author': 'IZIsolution',
    'website': 'https://erpviet.vn',
    'license': 'LGPL-3',
    'depends': [
        'ev_account_asset_revaluation',
        'ev_account_asset_liquidation',
        'ev_account_asset_lost',
        'ev_account_asset_write_off',
        'ev_account_asset_inventory',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/account_asset_decrease_views.xml',
        'views/account_asset_liquidation_views.xml',
        'views/account_asset_mark_lost_views.xml',
        'views/account_asset_write_off_views.xml',
        'views/account_asset_erpviet_views.xml',
        'views/account_asset_inventory_views.xml',
    ],
    'installable': True,
    'auto_install': False,
}
