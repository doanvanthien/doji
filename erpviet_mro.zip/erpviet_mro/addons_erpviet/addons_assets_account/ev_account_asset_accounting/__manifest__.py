# -*- coding: utf-8 -*-
{
    'name': 'Asset ERPViet — Accounting Layer',
    'summary': 'Lớp kế toán mỏng cho tài sản ERPViet: account.move + bảng khấu hao + stat-button',
    'category': 'Accounting/Assets',
    'version': '16.0.1.0.0',
    'author': 'IZIsolution',
    'website': 'https://erpviet.vn',
    'license': 'LGPL-3',
    'depends': [
        'ev_account_asset_base',
        'ev_account_asset',
        'account',
    ],
    'data': [
        'security/asset_accounting_security.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'auto_install': False,
}
