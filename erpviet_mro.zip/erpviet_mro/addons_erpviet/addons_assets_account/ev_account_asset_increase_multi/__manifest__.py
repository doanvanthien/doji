# -*- coding: utf-8 -*-
{
    'name': 'Ghi tăng tài sản hàng loạt',
    'summary': 'Phiếu ghi tăng tài sản cố định hàng loạt (kế toán)',
    'category': 'Assets',
    'version': '0.1',
    'author': 'IZIsolution',
    'website': 'https://izisolution.vn',
    'license': 'LGPL-3',
    'depends': [
        'ev_account_asset_revaluation',
        'ev_account_asset_base',
        'ev_account_asset_accounting',
        'ev_business_unit',
        'queue_job',
    ],
    'data': [
        'security/ir.model.access.csv',
        'data/sequences.xml',
        'views/account_asset_increase_multi_views.xml',
        'views/menu_views.xml',
    ],
    'installable': True,
    'application': False,
}
