# -*- coding: utf-8 -*-
{
    'name': 'Asset Revaluation, Financial Increase & Decrease',
    'summary': 'Phiếu đánh giá lại, ghi tăng, ghi giảm tài sản cố định (kế toán)',
    'category': 'Accounting/Assets',
    'version': '16.0.1.1.1',
    'author': 'ERPViet',
    'website': 'https://erpviet.vn',
    'license': 'LGPL-3',
    'depends': [
        'ev_account_asset',
        'ev_account_asset_base',
        'ev_account_asset_accounting',
        'ev_account_asset_asset',
        'ev_account_asset_master_data'
    ],
    'data': [
        'security/ir.model.access.csv',
        'security/record_rules.xml',
        'data/sequences.xml',
        'data/config_parameter.xml',
        'views/account_asset_revaluation_views.xml',
        'views/account_asset_increase_views.xml',
        'views/account_asset_decrease_views.xml',
        'views/account_asset_inherit_views.xml',
        'views/asset_modify_views.xml',
        'views/account_asset_pause_wizard_views.xml',
    ],
}
