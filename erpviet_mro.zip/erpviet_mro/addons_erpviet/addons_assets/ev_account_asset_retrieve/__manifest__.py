# -*- coding: utf-8 -*-
{
    'name': 'Asset Retrieve',
    'description': """
        Asset Retrieve
    """,
    'category': 'Hidden',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset',
                'hr',
                'account',
                'uom',
                'ev_account_asset_asset',
                'ev_account_asset_base',
                'ev_account_asset_damaged',
                'populating_ms_word_template'],
    'data': [
        'security/retrieve_security.xml',
        'security/ir.model.access.csv',
        'data/sequence_data.xml',
        'data/print_retrieve.xml',
        'views/account_asset_retrieve_views.xml',
        'views/account_asset_retrieve_line_views.xml',
        'views/account_asset_retrieve_multi_views.xml',
        'views/account_asset_propose_retrieve_views.xml',
        'views/account_asset_propose_retrieve_line_views.xml',
        'views/account_asset_views.xml',
        'views/account_asset_detail_views.xml',
        'views/account_asset_asset_views.xml',
        'views/account_asset_propose_action_views.xml',
        'wizard/account_asset_retrieve_reject_views.xml',
        'views/menu_views.xml',
    ],
    'demo': [
    ],
    'assets': {
        'web.assets_backend': [
        ]
    }

}
