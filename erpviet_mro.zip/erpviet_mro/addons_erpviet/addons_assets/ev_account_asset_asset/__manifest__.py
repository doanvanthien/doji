# -*- coding: utf-8 -*-
{
    "name": "Asset Asset ERPViet",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ["web", 'ev_account_asset', 'hr', 'account', 'ev_account_asset_base',
                'ev_account_asset_master_data', 'ev_business_unit', 'stock', 'base'],
    "data": [
        'security/account_asset_asset_security.xml',
        'security/ir.model.access.csv',
        # 'views/menu_views.xml',
        'views/account_asset_detail_views.xml',
        'views/account_asset_history_views.xml',
        'views/account_asset_asset_views.xml',
        # 'wizard/asset_modify_views.xml',
        'wizard/account_asset_qr_code.xml',
        'reports/template_qr_code.xml',
        'reports/template_preview_print_tem.xml',
        # 'views/account_asset_tools_views.xml',
        # 'views/account_asset_expense_views.xml',
    ],
}
