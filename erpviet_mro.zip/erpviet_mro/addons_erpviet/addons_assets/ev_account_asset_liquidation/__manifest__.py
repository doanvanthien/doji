# -*- coding: utf-8 -*-
{
    'name': 'Assets Liquidation',
    'description': """
        Assets Liquidation
    """,
    'category': 'Hidden',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset', 'ev_account_asset_asset', 'ev_account_asset_base', 'ev_business_unit', 'hr', 'web', 'web_domain_field', 'populating_ms_word_template'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/account_asset_propose_liquidation_data.xml',
        'data/account_asset_propose_liquidation.xml',
        # 'views/menu_views.xml',
        'views/account_asset_propose_liquidation_views.xml',
        'views/account_asset_propose_liquidation_line_views.xml',
        'views/account_asset_propose_liquidation_multi_views.xml',
        # 'views/account_asset_propose_liquidation_button_views.xml',
        # 'views/account_asset_liquidation_views.xml',
        'views/account_asset_liquidation_line_views.xml',
        'views/account_asset_liquidation_multi_views.xml',
        # 'views/account_asset_detail_views.xml',
        'wizards/account_asset_propose_liquidation_views.xml',
        'wizards/account_asset_propose_liquidation_multi_views.xml',
    ],
    'demo': [
    ],
    'assets': {
    }
}
