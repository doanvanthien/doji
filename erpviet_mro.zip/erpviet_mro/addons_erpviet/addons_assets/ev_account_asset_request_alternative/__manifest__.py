# -*- coding: utf-8 -*-
{
    'name': "EV Account Assets Request Alternative",

    'summary': """""",

    'description': """""",

    'author': "ERP Việt",
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'mail', 'ev_account_asset_base'],

    # always loaded
    'data': [
        'security/security.xml',
        'security/erpviet_account_asset_group.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/account_asset_request_alternative_view.xml',
    ],
    # only loaded in demonstration mode
    'demo': [],
}
