# -*- coding: utf-8 -*-
{
    'name': 'Assets Management Report - Báo cáo',
    'description': """
        Assets Management Report - Báo cáo
    """,
    'category': 'Accounting/Accounting',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['account', 'ev_account_asset_base', 'ev_account_asset', 'ev_account_asset_inventory', 'ev_report','ev_account_asset_allocation',
                'ev_account_asset_alternative','ev_account_asset_damaged','ev_account_asset_liquidation','ev_account_asset_lost','ev_account_asset_retrieve',
                'ev_account_asset_variation'
                ],
    'data': [
        'security/account_asset_security.xml',
        'security/ir.model.access.csv',
        #thinh
        'data/assets/account_asset_report_department_data.xml',
        'wizard/account_asset_report_department_views.xml',
        #duong
        'data/assets/account_asset_report_liquidation_data.xml',
        'wizard/account_asset_report_liquidation_views.xml',
        #nghia
        'data/assets/account_asset_report_location_data.xml',
        'wizard/account_asset_report_location_views.xml',
        #vietduc
        'data/assets/account_asset_report_summary_employee_data.xml',
        'wizard/account_asset_report_summary_employee_views.xml',
        'data/assets/account_asset_report_summary_department_data.xml',
        'wizard/account_asset_report_summary_department_views.xml',
        'data/assets/account_asset_report_summary_business_unit_data.xml',
        'wizard/account_asset_report_summary_business_unit_views.xml',
        #tanduc
        'data/assets/account_asset_report_business_unit_data.xml',
        'wizard/account_asset_report_business_unit_views.xml',
        #phuoc
        'data/assets/account_asset_report_asset_status_data.xml',
        'wizard/account_asset_report_asset_status_views.xml',
        'data/assets/account_asset_report_inventory_data.xml',
        'wizard/account_asset_report_inventory_views.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'ev_account_asset_report/static/src/scss/styles.scss',
        ],

    },
}
