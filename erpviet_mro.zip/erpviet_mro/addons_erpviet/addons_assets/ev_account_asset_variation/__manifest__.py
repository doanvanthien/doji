# -*- coding: utf-8 -*-
{
    "name": "Asset Variation ERPViet",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ["web", 'ev_account_asset', 'ev_account_asset_base', 'ev_account_asset_master_data', 'ev_business_unit'],
    "data": [
        'security/ir.model.access.csv',
        'data/account_asset_variation_data.xml',
        'views/account_asset_increase_views.xml',
        'views/account_asset_decrease_views.xml',

        
    ],
}
