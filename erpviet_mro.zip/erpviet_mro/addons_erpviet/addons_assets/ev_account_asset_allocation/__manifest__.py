# -*- coding: utf-8 -*-
{
    'name': 'Assets Allocation',
    'summary': 'Assets Allocation',
    'description': """
        Assets Allocation
    """,
    'category': 'Assets',
    'sequence': 32,
    'author': "ERPViet",
    'license': 'LGPL-3',
    'website': "https://erpviet.vn",
    'depends': ['ev_account_asset', 'ev_account_asset_base', 'ev_account_asset_master_data',
                'ev_account_asset_asset', 'ev_business_unit',
                'ev_account_asset_variation', 'web_domain_field',
                'populating_ms_word_template'],
    'data': [
        'security/account_asset_allocation_security.xml',
        'security/ir.model.access.csv',
        'data/asset_request_allocation_data.xml',
        'data/asset_allocation_data.xml',
        'data/asset_allocation_multi_data.xml',
        'data/account_asset_allocation_report.xml',
        'views/account_asset_request_allocation_views.xml',
        'views/account_asset_allocation_views.xml',
        'views/account_asset_allocation_multi_views.xml',
        'views/account_asset_allocation_line_views.xml',
        'views/account_asset_asset_views.xml',
        'wizard/account_asset_allocation_reject_views.xml',
    ],
    'demo': [

    ],
    'assets': {

    }
}
