# -*- coding: utf-8 -*-
{
    'name': 'ERPVIET - Cập nhật tài sản đầu kỳ',
    'description': """
        Nhập hàng loạt tài sản cố định đầu kỳ từ file Excel vào hệ thống ERPVIET.
    """,
    'sequence': 32,
    'author': 'IZISolution',
    'license': 'LGPL-3',
    'website': 'https://izisolution.vn',
    'category': 'Asset',
    'version': '0.1',
    'depends': ['hr', 'ev_account_asset_asset', 'queue_job'],
    'data': [
        'data/sequence_data.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizard/cap_nhat_tsdk_tmp_views.xml',
        'views/cap_nhat_tsdk_views.xml',
    ],
    'demo': [],
}
