# -*- coding: utf-8 -*-
{
    "name": "Bảo dưỡng sửa chữa tài sản",
    # "category": "HCSN",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    'depends': ['ev_account_asset',
                'hr',
                'account',
                'uom',
                'ev_account_asset_asset',
                'ev_account_asset_base',
                'ev_account_asset_damaged',
                'populating_ms_word_template'],
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence_data.xml',
        'views/account_asset_maintenance_line_views.xml',
        'views/account_asset_maintenance_views.xml',
        'views/account_asset_maintenance_action_views.xml',
    ],
}
