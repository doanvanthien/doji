# -*- coding: utf-8 -*-
{
    'name': 'Assets Management - Quản trị tài sản',
    'description': """
        Assets Management  - Quản trị tài sản
    """,
    'category': 'Accounting/Accounting',
    'sequence': 32,
    'author': 'ERPViet',
    'website': 'https://erpviet.vn',
    'license': 'LGPL-3',
    'depends': ['account'],
    'data': [
        'security/account_asset_security.xml',
        'security/ir.model.access.csv',
        'wizard/asset_modify_views.xml',
        'views/account_account_views.xml',
        'views/account_asset_views.xml',
        'views/account_deferred_revenue.xml',
        'views/account_deferred_expense.xml',
        'views/account_move_views.xml',
        # 'data/asset_report.xml',
        # 'data/account_report_actions.xml',
        # 'data/menuitems.xml',
    ],
    'demo': [
        'demo/account_deferred_revenue_demo.xml',
        'demo/account_asset_demo.xml',
    ],
    'assets': {

        'web.assets_backend': [
            'ev_account_asset/static/src/scss/account_asset.scss',
            'ev_account_asset/static/src/components/**/*'
        ],
        'web.dark_mode_assets_backend': [
            'ev_account_asset/static/src/scss/*.dark.scss',
        ],
    }
}
