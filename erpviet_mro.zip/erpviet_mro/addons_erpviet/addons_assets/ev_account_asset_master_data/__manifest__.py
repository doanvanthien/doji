# -*- coding: utf-8 -*-
{
    'name': 'Assets Master Data',
    'description': """
        Assets Master Data
    """,
    'category': 'Hidden',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset', 'ev_account_asset_base', 'hr', 'account', 'uom', 'account', 'ev_business_unit', 'stock'],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/asset_category_demo.xml',
        'views/menu_views.xml',
        'views/account_asset_withdrawal_rationale_views.xml',
        'views/account_asset_allocation_rationale_views.xml',
        'views/account_asset_assessment_rationale_views.xml',
        'views/account_asset_increase_decrease_rationale_views.xml',
        'views/account_asset_location_views.xml',
        'views/hr_department_views.xml',
        'views/hr_employee_views.xml',
        'views/hr_job_views.xml',
        'views/account_asset_type_views.xml',
        'views/account_account_views.xml',
        'views/supplier_views.xml',
        'views/account_asset_origin_views.xml',
        'views/customer_views.xml',
        'views/uom_uom_views.xml',
        'views/ir_actions_report_views.xml',
        'views/account_asset_zone_views.xml',
        'views/product_template_views.xml',
        'views/account_asset_category_views.xml',
    ],
    'demo': [
    ],
    'assets': {
    }
}
