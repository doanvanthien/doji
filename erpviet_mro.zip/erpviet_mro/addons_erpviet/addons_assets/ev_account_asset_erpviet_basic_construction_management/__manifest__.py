{
    "name": "Công trình xây dựng cơ bản",
    "category": "HCSN",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ['account', 'base'],
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/account_asset_erpviet_basic_construction_management_views.xml',
    ],
}
