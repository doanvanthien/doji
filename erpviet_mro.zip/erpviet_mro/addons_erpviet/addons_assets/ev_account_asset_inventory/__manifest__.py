# -*- coding: utf-8 -*-
{
    "name": "Asset ERPViet Inventory",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": [
        "base", 
        'ev_account_asset', 
        'ev_account_asset_asset', 
        'ev_account_asset_base', 
        'ev_account_asset_master_data',
        'ev_business_unit',
        'ev_account_asset_allocation',
        'ev_account_asset_acquisition_plan',
        'ev_account_asset_allowcation_rate',
        'ev_account_asset_alternative',
        'ev_account_asset_variation',
        'ev_account_asset_damaged',
        'ev_account_asset_liquidation',
        'ev_account_asset_loan',
        'ev_account_asset_lost',
        'ev_account_asset_maintenance',
        'ev_account_asset_request_alternative',
        'ev_account_asset_retrieve',
        'ev_account_asset_write_off',
        'queue_job'
    ],
    'external_dependencies': {
        'python': ['numpy', 'openpyxl','unidecode']
    },
    "data": [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/account_asset_inventory_data.xml',
        # 'data/account_asset_inventory_template_data.xml',

        'views/menu_views.xml',
        'views/account_asset_inventory_views.xml',
        'views/account_asset_inventory_line_views.xml',
        'views/account_asset_inventory_detail.xml',
        'views/account_asset_inventory_detail_unlisted_views.xml',
        'views/account_asset_inventory_line_unlisted_views.xml',
        'views/account_asset_inventory_council.xml',
        'views/account_asset_discrepancy_resolution_views.xml',
        'views/account_asset_discrepancy_resolution_line_views.xml',
        'views/account_asset_discrepancy_resolution_line_unlisted_views.xml',

        'wizards/account_asset_inventory_confirmation_views.xml',
        'reports/account_asset_inventory_report.xml'
    ],
}
