# -*- coding: utf-8 -*-
{
    'name': 'Assets Alternative',
    'category': 'Hidden',
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset', 'ev_account_asset_base', 'hr', 'account', 'web', 'ev_account_asset_asset',
                'ev_account_asset_master_data', 'ev_business_unit', 'web_domain_field', 'ev_account_asset_request_alternative'],
    'data': [
        'security/account_asset_alternative_security.xml',
        'security/ir.model.access.csv',
        'data/account_asset_alternative_data.xml',
        'data/account_asset_alternative_report.xml',
        # 'views/menu_views.xml',
        'views/account_asset_alternative_views.xml',
        'views/account_asset_alternative_line_views.xml',
        'views/account_asset_alternative_multi_views.xml',
        'views/account_asset_request_alternative_views.xml',
    ],
    'demo': [
    ],
    'assets': {
    }
}
