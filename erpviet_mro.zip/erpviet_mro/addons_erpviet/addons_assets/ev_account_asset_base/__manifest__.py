# -*- coding: utf-8 -*-
{
    "name": "Asset ERPViet Base",
    "category": "Hidden",
    'version': '16.0.1.1.0',
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ["web", 'ev_account_asset', 'hr', 'account','ev_business_unit'],
    "data": [
        'security/asset_security.xml',
        'security/ir.model.access.csv',
        'views/menu_views.xml',
        'views/account_asset_detail_update_views.xml',
        'views/account_asset_summary_views.xml',
    ],
}
