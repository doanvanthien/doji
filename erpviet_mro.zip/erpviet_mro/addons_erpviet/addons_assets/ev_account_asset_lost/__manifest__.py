# -*- coding: utf-8 -*-
{
    'name': 'Assets Lost',
    'category': 'Hidden',
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset', 'ev_account_asset_base', 'hr', 'account', 'web', 'ev_account_asset_asset',
                'ev_account_asset_master_data', 'ev_business_unit', 'web_domain_field', 'ev_account_asset_damaged'],
    'data': [
        'security/ir.model.access.csv',
        'security/account_asset_mark_lost_security.xml',
        'data/account_asset_lost_data.xml',
        'data/account_asset_lost_report_data.xml',
        'views/account_asset_mark_lost_views.xml',
        'views/account_asset_detail.xml',
        'views/account_asset_mark_lost_line_views.xml',
        'views/account_asset_mark_lost_multi_views.xml',
        'views/account_asset_lost_action_views.xml',
        'views/account_asset_report_lost_views.xml',
        'views/account_asset_report_lost_line_views.xml',
        'views/account_asset_handle_lost_views.xml',
        'views/account_asset_handle_lost_line_views.xml',
        'views/account_asset_reject_lost_views.xml',
        'views/account_asset_reject_lost_line_views.xml',
        'wizards/account_asset_report_lost_reject_views.xml',

    ],
    'demo': [
    ],
    'assets': {
    }
}
