# -*- coding: utf-8 -*-
{
    "name": "Damaged Asset ERPViet",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ["web", 'ev_account_asset', 'hr', 'account', 'ev_account_asset_base', 'ev_account_asset_master_data','ev_account_asset_asset','ev_business_unit','web_domain_field', 'populating_ms_word_template' ],
    "data": [
        'security/ir.model.access.csv',
        'security/security.xml',
        'data/account_asset_damaged_data.xml',
        'data/account_asset_damaged_report.xml',
        'views/menu_views.xml',
        'views/account_asset_mark_damaged_views.xml',
        'views/account_asset_mark_damaged_line_views.xml',
        'views/account_asset_mark_damaged_multi_views.xml',
        'views/account_asset_report_damaged_views.xml',
        'views/account_asset_report_damaged_line_views.xml',
        'views/account_asset_reject_damaged_views.xml',
        'views/account_asset_reject_damaged_line_views.xml',
        'views/account_asset_handle_damaged_views.xml',
        'views/account_asset_handle_damaged_line_views.xml',
        'views/account_asset_detail.xml',
        'wizards/account_asset_report_damaged_reject_views.xml',

    ],
}
