# -*- coding: utf-8 -*-
{
    'name': 'EV Account asset write off',
    'description': """
        EV Account asset write off
    """,
    'category': 'Hidden',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset',
                'hr',
                'account',
                'uom',
                'ev_account_asset_asset',
                'ev_account_asset_base',
                'ev_account_asset_damaged',
                'populating_ms_word_template'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/account_asset_write_off_views.xml',
        'views/account_asset_write_off_line_views.xml',
    ],
    'demo': [
    ],
    'assets': {
    }
}
