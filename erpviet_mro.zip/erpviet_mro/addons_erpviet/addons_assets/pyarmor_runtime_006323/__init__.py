# Pyarmor 8.5.10 (group), 006323, 2026-10-02T09:26:25.140224
from .pyarmor_runtime import __pyarmor__
