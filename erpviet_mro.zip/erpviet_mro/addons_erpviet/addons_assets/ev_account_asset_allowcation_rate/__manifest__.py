# -*- coding: utf-8 -*-
{
    'name': 'Định mức cấp phát',
    'description': """
        Định mức cấp phát
    """,
    'category': 'Hidden',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['hr', 'account', 'uom', 'ev_business_unit', 'ev_vietnam_states',
                'ev_account_asset_master_data', 'ev_account_asset_allocation'],
    'data': [
        'security/ir.model.access.csv',
        'security/account_asset_allocation_rate_security.xml',
        'views/account_asset_allocation_rate_views.xml',
        'views/account_asset_allocation_multi_inherit_views.xml',
    ],
    'demo': [
    ],
    'assets': {
    }
}
