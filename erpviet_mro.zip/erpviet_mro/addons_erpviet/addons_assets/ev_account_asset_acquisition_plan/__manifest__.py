# -*- coding: utf-8 -*-
{
    'name': 'EV Account asset acquisition plan',
    'description': """
        EV Account asset acquisition plan
    """,
    'category': 'Hidden',
    'sequence': 32,
    'author': 'ERPViet',
    'license': 'LGPL-3',
    'website': 'https://erpviet.vn',
    'depends': ['ev_account_asset',
                'hr',
                'account',
                'uom',
                'ev_account_asset_asset',
                'ev_account_asset_base', 'ev_account_asset_master_data',
                'ev_account_asset_allowcation_rate', 'ev_account_asset_damaged',
                'populating_ms_word_template'],
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/sequence.xml',
        'views/account_asset_acquisition_plan_views.xml',
        'views/account_asset_acquisition_plan_line_views.xml',

    ],
    'demo': [
    ],
    'assets': {
    }
}
