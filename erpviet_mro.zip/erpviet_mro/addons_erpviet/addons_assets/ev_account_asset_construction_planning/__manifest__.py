# -*- coding: utf-8 -*-
{
    "name": "Asset Construction Planning",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": [
        # 'ev_kt_hcsn_danh_muc',
        'ev_account_asset_base',
    ],
    "data": [
        'data/sequence.xml',
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/account_asset_erpviet_construction_planning_views.xml',
        # 'views/account_asset_summary_views.xml',
    ],
}
