# -*- coding: utf-8 -*-
{
    'name': "EV MRO Assets Import",

    'summary': """""",

    'description': """""",

    'author': "IZISolution",
    'website': "https://izisolution.vn",
    'category': 'Asset',
    'version': '0.1',
    'depends': ['asset'],
    'data': [
        # 'views/asset_meter_update_view.xml',
        # 'views/asset_meter_import_view.xml',
        'security/ir.model.access.csv',
        'views/asset_asset_import_views.xml',
        # 'views/asset_detail_import_view.xml'
    ],
}
