# -*- coding: utf-8 -*-
{
    'name': 'MRO Account Asset Link',
    'version': '1.0',
    'category': 'Maintenance',
    'summary': 'Link between Equipment and Accounting Assets',
    'description': """
        Thêm trường quan hệ one2many từ thiết bị (asset.asset) đến tài sản kế toán (account.asset.erpviet).
    """,
    'author': 'ERPViet',
    'depends': ['asset', 'ev_account_asset_asset'],
    'data': [
        'views/asset_asset_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
