# -*- coding: utf-8 -*-
{
    'name': "EV Stock Report",
    'summary': """Báo cáo kho""",
    'description': """Báo cáo kh""",
    'author': "ERPViet",
    'website': "https://www.erpviet.vn",
    'category': 'Stock',
    'version': '6.0.0.3',
    'license': 'AGPL-3',
    'depends': ['stock', 'ev_stock_materialized', 'ev_postgresql_materialized', 'ev_report'],
    'data': [
        'security/ir.model.access.csv',
        'data/report_stock_in_out_document_data.xml',
        'data/report_stock_inventory_data.xml',
        'wizards/report_stock_in_out_document_views.xml',
        'wizards/report_stock_inventory_views.xml',
    ],
}
