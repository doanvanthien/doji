# -*- coding: utf-8 -*-
{
    "name": "EV MRO Request",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ['ev_mro_master_data', 'mro', 'asset'],
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/ir_sequence.xml',
        'views/mro_request_view.xml',
        'views/mro_report_issue_view.xml',
        # 'views/mro_order_view.xml',
        # 'views/menu_views.xml',
        'wizard/mro_request_reject_wizard_view.xml',
        'data/action_approve_mro_request.xml',
    ],
}
