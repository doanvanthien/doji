# -*- coding: utf-8 -*-
{
    "name": "MRO ERPViet Base",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ['web', 'hr', 'account','ev_business_unit'],
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/menu_views.xml',
        'views/thong_tin_cap_nhat_views.xml',

    ],
}
