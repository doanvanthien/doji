odoo.define('mro_dashboard_vi.ks_dashboard_ninja', function(require) {
    "use strict";

    var KsDashboardNinja = require('ks_dashboard_ninja.ks_dashboard');

    KsDashboardNinja.include({
        init: function(parent, state, params) {
            this._super.apply(this, arguments);
            // Ghi đè từ điển tiếng Việt sau khi init
            this.ks_date_filter_selections = {
                'l_none': 'Bộ lọc Ngày',
                'l_day': 'Hôm nay',
                't_week': 'Tuần này',
                'td_week': 'Từ đầu tuần đến nay',
                't_month': 'Tháng này',
                'td_month': 'Từ đầu tháng đến nay',
                't_quarter': 'Quý này',
                'td_quarter': 'Từ đầu quý đến nay',
                't_year': 'Năm nay',
                'td_year': 'Từ đầu năm đến nay',
                'n_day': 'Ngày tiếp theo',
                'n_week': 'Tuần tiếp theo',
                'n_month': 'Tháng tiếp theo',
                'n_quarter': 'Quý tiếp theo',
                'n_year': 'Năm tiếp theo',
                'ls_day': 'Hôm qua',
                'ls_week': 'Tuần trước',
                'ls_month': 'Tháng trước',
                'ls_quarter': 'Quý trước',
                'ls_year': 'Năm trước',
                'l_week': '7 ngày qua',
                'l_month': '30 ngày qua',
                'l_quarter': '90 ngày qua',
                'l_year': '365 ngày qua',
                'ls_past_until_now': 'Quá khứ đến hiện tại',
                'ls_pastwithout_now': 'Quá khứ không bao gồm hôm nay',
                'n_future_starting_now': 'Tương lai từ bây giờ',
                'n_futurestarting_tomorrow': 'Tương lai từ ngày mai',
                'l_custom': 'Bộ lọc tùy chỉnh',
            };
        }
    });
});
