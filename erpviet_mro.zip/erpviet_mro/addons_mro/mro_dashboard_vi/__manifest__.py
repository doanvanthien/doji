# -*- coding: utf-8 -*-
{
    'name': 'MRO Dashboard Vietnamese',
    'version': '1.0',
    'summary': 'Vietnamese translation override for ks_dashboard_ninja',
    'sequence': 10,
    'description': """
        Kế thừa module ks_dashboard_ninja để Việt hóa giao diện Javascript và XML.
    """,
    'category': 'Customizations',
    'author': 'Antigravity AI',
    'depends': ['ks_dashboard_ninja', 'ks_dn_advance'],
    'data': [],
    'assets': {
        'web.assets_backend': [
            'mro_dashboard_vi/static/src/js/ks_dashboard_ninja_vi.js',
            'mro_dashboard_vi/static/src/xml/ks_dashboard_ninja_templates_vi.xml',
        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
    'license': 'LGPL-3',
}
