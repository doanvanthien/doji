# -*- coding: utf-8 -*-
{
    'name': "Dashboard for Maintenance",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    'category': 'Hidden',
    # any module necessary for this one to work correctly
    'depends': ['base', 'bus', 'asset', 'ev_mro_order', 'ev_mro_request'],
    'assets': {
        'web.assets_backend': [
            'ev_mro_dashboard/static/src/css/mro_kanban.css',
        ],
    },
    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/menu_views.xml',
        'views/mro_dashboard.xml',
        'views/search_izi_mro_custom_view.xml',
        'views/mro_order.xml',
        'views/mro_request.xml',
        'data/data_view.xml',
    ],
}
