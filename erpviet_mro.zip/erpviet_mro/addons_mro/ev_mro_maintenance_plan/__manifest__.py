# -*- coding: utf-8 -*-
{
    "name": "MRO ERPViet Maintenance Plan",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ['web', 'hr', 'account', 'ev_business_unit', 'ev_mro_base',
                'stock', 'uom', 'ev_mro_master_data', 'mro', 'asset'],
    "data": [
        'security/security.xml',
        'security/ir.model.access.csv',
        'data/data.xml',
        'data/action_wait_tbp_approved.xml',
        # 'views/mro_pm_rule_views.xml',
    ],
}
