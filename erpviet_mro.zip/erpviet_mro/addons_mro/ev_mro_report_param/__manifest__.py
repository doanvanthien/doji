# -*- coding: utf-8 -*-
{
    'name': "MRO Report Param",
    'author': "IZISolution",
    'summary': "IZI Solution",
    'website': "http://www.izisolution.vn",
    'category': 'Report custom',
    'version': '0.1',
    'depends': ['ev_mro_base', 'ev_mro_master_data', 'ev_report', 'base'],
    'data': [
        ],
}
