# -*- coding: utf-8 -*-
{
    'name': "EV Stock Materialized",
    'summary': """Quản lý bảng tổng hợp dữ liệu trong phân hệ kho""",
    'description': """Quản lý bảng tổng hợp dữ liệu trong phân hệ kho""",
    'author': "ERPViet",
    'website': "http://www.erpviet.vn",
    'category': 'Tools',
    'version': '6.0.0.2',
    'license': 'AGPL-3',
    'depends': ['ev_postgresql_materialized', 'base'],
}
