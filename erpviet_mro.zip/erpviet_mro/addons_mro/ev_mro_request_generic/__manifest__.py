# -*- coding: utf-8 -*-
{
    'name': 'MRO Request Generic Equipment',
    'version': '16.0.1.0.0',
    'category': 'Maintenance',
    'summary': 'Allow MRO requests without specific equipment',
    'depends': [
        'ev_mro_request',
        'ev_mro_master_data',
    ],
    'data': [
        'data/generic_data.xml',
        'views/mro_request_view.xml',
    ],
    'installable': True,
    'auto_install': False,
    'application': False,
}
