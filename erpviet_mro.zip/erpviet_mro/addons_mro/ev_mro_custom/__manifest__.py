# -*- coding: utf-8 -*-
{
    "name": "EV MRO Custom",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    "depends": ['web', 'hr', 'account', 'ev_business_unit', 'ev_mro_master_data', 'ev_mro_base', 'ev_mro_order',
                'mro', 'asset', 'ks_dashboard_ninja', 'spreadsheet_dashboard'],
    "data": [
        # 'security/security.xml',
        'security/ir.model.access.csv',
        # 'data/data.xml',
        'views/ssc_mro_confirm_order_views.xml',
        'views/ssc_mro_confirm_pm_order_views.xml',
        'views/ssc_mro_order_return_work_views.xml',
        'views/additional_parts_view.xml',
        'views/mro_returned_parts_view.xml',
        'views/ssc_mro_order_done_views.xml',
        'views/menu_views.xml',
    ],
}
