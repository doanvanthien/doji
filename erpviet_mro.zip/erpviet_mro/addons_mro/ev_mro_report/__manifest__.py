# -*- coding: utf-8 -*-
{
    'name': "MRO Report",
    'author': "IZISolution",
    'summary': "IZI Solution",
    'website': "https://izisolution.vn",
    'category': 'Report custom',
    'version': '0.1',
    'depends': ['ev_mro_base', 'ev_mro_master_data', 'ev_report', 'base','ev_mro_report_param'],
    'assets': {
        'web.assets_backend': [
            'ev_mro_report/static/src/css/styles.scss',
        ],
    },
    'data': [
        'security/ir.model.access.csv',

        'views/mro_maintenance_report_view.xml',
        'views/mro_order_report_ne_view.xml',
        'views/mro_order_report_view.xml',
        'views/mro_maintenance_report_plan_view.xml',
        'views/mro_maintenance_report_actual_view.xml',
        'views/mro_maintenance_report_weekly.xml',
        'views/mro_order_cost_repair.xml',
        'views/mro_order_cost_maintenance.xml',
        'views/mro_maintenance_report_plan_synthetic.xml',
        'views/mro_maintenance_plan_report.xml',
        'views/mro_maintenance_report_summary.xml',
        'views/mro_maintenance_report_summary_detail.xml',
        'views/mro_maintenance_lookup_view.xml',
        'views/mro_task_report_detail_view.xml',
        'views/asset_matrix_report_view.xml',
        'views/mro_checklist_detail_report_view.xml',

    ],
}
