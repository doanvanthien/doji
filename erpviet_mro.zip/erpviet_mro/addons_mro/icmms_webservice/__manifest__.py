# -*- coding: utf-8 -*-
{
    "name": "EV MRO ICMMS Webservice",
    "category": "Hidden",
    'author': "ERPViet",
    'website': "https://erpviet.vn",
    "license": "LGPL-3",
    'depends': ['base', 'asset', 'mro', 'ev_mro_order', 'ev_mro_request'],

    'data': [
        'security/ir.model.access.csv',
        'data/ir_cron.xml',
        'views/api_log_views.xml',
    ],
}
